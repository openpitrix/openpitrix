#!/bin/bash -e

yum install -y docker
service docker start
